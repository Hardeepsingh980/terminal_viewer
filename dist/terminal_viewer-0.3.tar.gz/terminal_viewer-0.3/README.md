# Terminal Viewer
Python Package for viewing Images in terminal. Does this sound cool? 

## How to Use?

To use this package follow below:- 

```
from terminal_viewer import show_image

show_image('hello.jpg', 100)
```

#### Note Resize the terminal window for better results.
#### It Only works in bash terminal.

## Screenshots

![alt text](https://github.com/Hardeepsingh980/terminal_viewer/blob/master/screenshots/1.jpg?raw=true)